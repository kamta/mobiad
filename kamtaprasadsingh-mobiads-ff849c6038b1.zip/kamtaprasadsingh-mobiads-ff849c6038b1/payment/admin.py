from django.contrib import admin
from .models import *
class PaymentTrackAdmin(admin.ModelAdmin):
    list_display = ('user','payment_id','amount','amount_received','status','source','rate','plan','added_date_time','payment_date_time')
class PaymentPlanAdmin(admin.ModelAdmin):
    list_display = ('name','price','active')
    list_editable = ('active',)
    

admin.site.register(PaymentTrack,PaymentTrackAdmin)
admin.site.register(PaymentPlan,PaymentPlanAdmin)
