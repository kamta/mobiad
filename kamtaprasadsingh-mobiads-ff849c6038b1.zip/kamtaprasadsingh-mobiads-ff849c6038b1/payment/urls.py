from django.conf.urls import url
from .views import payment_history,purchase_credit,payment

urlpatterns = [
    url(r'payment/history/$', payment_history, name='payment_history'),
    url(r'payment/purchase-credit/$', purchase_credit, name='purchase_credit'),
    url(r'payment/$', payment, name="payment"),

]
