from django.conf.urls import url
from django.views.generic import TemplateView
from .views import *
urlpatterns = [
    url(r'^publisher/reports/$', publisher_reports, name='publisher_reports'),
    url(r'^publisher/sites/$', publisher_sites, name='pulisher_sites'),
    url(r'^publisher/sites/add/$', change_publisher_sites, name='add_pulisher_sites'),
    url(r'^publisher/sites/change/(?P<slug>.+)/$', change_publisher_sites, name="site_change"),
    url(r'^publisher/sites/review/(?P<site_id>\d+)/$', review_publisher_sites, name="review_publisher_sites"),
    url(r'^publisher/sites/view/(?P<slug>.+)/$', view_publisher_sites, name="view_publisher_sites"),

]
