from __future__ import absolute_import
from django import forms
from .models import PublisherSite


class PublisherSiteForm(forms.ModelForm):
    class Meta:
        model = PublisherSite
        exclude = ('site_status', 'mobile_traffic', 'desktop_traffic', 'user', 'slug' )



