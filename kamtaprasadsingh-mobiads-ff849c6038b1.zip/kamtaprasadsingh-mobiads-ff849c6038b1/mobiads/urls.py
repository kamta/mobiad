from django.conf.urls import url, include
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [     
    url(r'^', include('mailprocess.urls')),
    url(r'^', include('accounts.urls')),
    #url(r'^', include('docs.urls')),    
    #url(r'^api/v1/', include('api.urls')),
    url(r'^mysite/', include('payment.urls')),
    url(r'^mysite/', include('advertiser.urls')),
    url(r'^mysite/', include('publisher.urls')),
    url(r'^mysite/', include('template_manager.urls')),
    url(r'^mysite/', include('support.urls')),
    url(r'^admin/', admin.site.urls),
    #url(r'^', include('comparision.urls')),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
