from django.shortcuts import render
from .models import CampaignTemplate, TemplateCategory
from .forms import EmailTemplateForm
from django.http import HttpResponse, HttpResponseRedirect
import json
from django.contrib.auth.decorators import login_required
from mailprocess.decorators import login_required_ajax
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


@login_required
def templates_list(request):
    template_name = 'myadmin/template_manager/template_list.html'
    campaigntemplate = CampaignTemplate.objects.filter(user=request.user, active=True)
    paginator = Paginator(campaigntemplate, 10)
    page = request.GET.get('page')
    try:
        campaigntemplate = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        campaigntemplate = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        campaigntemplate = paginator.page(paginator.num_pages)
    return render(request, template_name, {'campaigntemplate': campaigntemplate})


@login_required
def templates_preview(request, slug):
    template_name = 'myadmin/template_manager/template_preview.html'
    if request.user.is_superuser:
        campaigntemplate = CampaignTemplate.objects.get(slug=slug)
    else:
        campaigntemplate = CampaignTemplate.objects.get(slug=slug, user=request.user)
    return render(request, template_name, {'campaigntemplate': campaigntemplate})


@login_required
def templates_change(request, slug=None):
    template_name = 'myadmin/template_manager/template_change.html'
    campaigntemplate = None
    if slug:
        campaigntemplate = CampaignTemplate.objects.get(slug=slug)
    if request.method == "POST":
        form = EmailTemplateForm(request.POST, request.FILES, instance=campaigntemplate)
        if form.is_valid():
            new_template = form.save(commit=False)
            new_template.user = request.user
            new_template.active = True
            new_template.save()
            return HttpResponse(json.dumps(1), content_type="application/json")
        else:
            return HttpResponse(json.dumps(form.errors), content_type="application/json")
    return render(request, template_name, { 'template': campaigntemplate,})


@login_required
def templates_delete(request, slug):
    emailtemplate = CampaignTemplate.objects.get(slug=slug, user=request.user)
    emailtemplate.active = False
    emailtemplate.save()
    return HttpResponseRedirect("/mysite/templates/")
