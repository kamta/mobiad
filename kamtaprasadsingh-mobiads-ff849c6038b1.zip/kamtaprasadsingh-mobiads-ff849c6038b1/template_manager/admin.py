from django.contrib import admin
from .models import *


class EmailCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'active', 'user', 'show_associated_template', 'added_date', 'modified_date')
    list_filter = ('active',)

    def show_associated_template(self, obj):
        return "<a href='/admin/template_manager/campaigntemplate/?templatecategory__name=%s'>Show Template</a>" % (
        obj.name)

    show_associated_template.allow_tags = True


class EmailTemplateAdmin(admin.ModelAdmin):
    list_display = (
    'template_name', 'templatecategory', 'template_type', 'headline1', 'headline2', 'description1', 'description2', 'adimage', 'icon',
    'final_url', 'display_url', 'is_public', 'active', 'user', 'template_preview', 'added_date', 'modified_date')
    search_fields = ('template_name',)
    list_filter = ('templatecategory__name', 'is_public', 'active', 'user__username')

    def template_preview(self, obj):
        return "<a href='/mysite/templates/preview/%s/' target='_blank'>preview</a>" % (obj.slug)

    template_preview.allow_tags = True


admin.site.register(TemplateCategory, EmailCategoryAdmin)
admin.site.register(CampaignTemplate, EmailTemplateAdmin)
