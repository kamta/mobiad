from django.contrib import admin
from .models import MetaData
  

class MetaDataAdmin(admin.ModelAdmin):    
    list_display = ('path','title','description','keywords','active','user','added_date','modified_date')
    list_editable = ('title','description','keywords')
    search_fields = ('path', )
admin.site.register(MetaData, MetaDataAdmin)