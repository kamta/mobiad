Prerequisite


sudo apt update
sudo apt install python3-pip
pip3 --version
sudo apt-get install python3-venv
sudo apt-get install python-dev default-libmysqlclient-dev
sudo apt-get install python3-dev
python3 -m venv mobiads_env

source mobiads_env/bin/activate
pip install -U wheel

pip install -r mobiads/requirements.txt



For Apache:

apt install libapache2-mod-wsgi # For Python2
apt install libapache2-mod-wsgi-py3 # For Python3


