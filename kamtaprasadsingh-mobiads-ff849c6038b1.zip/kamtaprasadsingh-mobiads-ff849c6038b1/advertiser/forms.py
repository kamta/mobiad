from __future__ import absolute_import
from django import forms
from .models import Campaign


class CampaignForm(forms.ModelForm):
    class Meta:
        model = Campaign
        exclude = ('user', 'slug', 'running_status', 'campaign_status', 't_impression_count', 't_click_count', 'running_status')
