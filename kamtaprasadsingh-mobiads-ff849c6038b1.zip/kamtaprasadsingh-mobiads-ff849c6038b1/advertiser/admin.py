from django.contrib import admin
from .models import *


class CampaignAdmin(admin.ModelAdmin):
    list_display = (
    'name', 'template', 'active', 'ad_format', 'running_status', 'campaign_status', 'campaign_type', 'budget',
    'cpc_cpm_bid', 'start_date', 'end_date', 'reason_for_rejection', 't_impression_count', 't_click_count', 'slug', 'user', 'added_date', 'modified_date')

    list_editable = ('campaign_status', 'reason_for_rejection')

class CampaignDetailAdmin(admin.ModelAdmin):
    list_display = ('campaign', 'publisher', 'report_type', 'active', 'source_ip', 'http_referer', 'added_date', 'updated_date')

admin.site.register(Campaign, CampaignAdmin)
admin.site.register(CampaignDetail, CampaignDetailAdmin)

