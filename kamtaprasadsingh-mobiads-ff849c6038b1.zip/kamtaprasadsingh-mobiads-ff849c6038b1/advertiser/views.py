import pytz
import json
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from datetime import datetime
from mailprocess.decorators import login_required_ajax
from template_manager.models import CampaignTemplate
from .models import Campaign, CampaignDetail
from .forms import CampaignForm
from mailprocess.choices import AD_CHOICE, CAMPAIGN_TYPE
from django.contrib.auth.models import User


@login_required
def advertiser_reports(request):
    campaigns = Campaign.objects.filter(campaign_status__gte=5, user=request.user)
    template_name = 'myadmin/advertiser/advertiser_reports.html'
    return render(request, template_name, {'campaigns': campaigns})


def advertiser_directlinkad_details(request, campaign_slug, username=None):
    campaign = Campaign.objects.get(active=True, slug=campaign_slug)
    campaign.t_click_count+=1
    campaign.t_impression_count+=1
    campaign.save()
    if username:
        user=User.objects.get(username=username)
        CampaignDetail.objects.create(campaign=campaign, report_type=campaign.campaign_type, publisher=user, price=campaign.cpc_cpm_bid)
    template_name = 'myadmin/advertiser/directlinkads_details.html'
    return render(request, template_name, {'campaign':campaign})


@login_required
def advertiser_directlinkads(request):
    campaigns = Campaign.objects.filter(active=True, campaign_status=6, ad_format__in = [1, 2]).order_by("-id")
    template_name = 'myadmin/advertiser/directlinkads.html'
    return render(request, template_name, {'campaigns':campaigns})


@login_required
def campaign_list(request):
    campaign = Campaign.objects.filter(user=request.user, active=True).exclude(campaign_status__gte=8).order_by("-id")

    paginator = Paginator(campaign, 10)
    page = request.GET.get('page')
    try:
        campaign = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        campaign = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        campaign = paginator.page(paginator.num_pages)
    template_name = 'myadmin/advertiser/campaign_list.html'
    return render(request, template_name, {'campaign_obj': campaign, })


@login_required_ajax
def campaign_change(request, slug=None):
    template_name = 'myadmin/advertiser/campaign_change.html'
    adtype = request.GET.get('adtype', 1)
    adtype_value = dict(AD_CHOICE).get(int(adtype))
    campaign = None
    if slug:
        campaign = Campaign.objects.get(slug=slug)
        adtype = campaign.ad_format
        adtype_value = campaign.get_ad_format_display()
    if request.method == "POST":
        form = CampaignForm(request.POST, instance=campaign)
        if form.is_valid():
            new_campaign = form.save(commit=False)
            new_campaign.user = request.user
            new_campaign.active = True
            new_campaign.campaign_status = 1
            new_campaign.running_status = 1
            new_campaign.timezone = None
            new_campaign.save()
            return HttpResponse(json.dumps(1), content_type="application/json")
        else:
            return HttpResponse(json.dumps(form.errors), content_type="application/json")
    template = CampaignTemplate.objects.filter(user=request.user, active=True, template_type=int(adtype))
    return render(request, template_name,
                  {'campaign_obj': campaign, 'templates': template, 'adtype': adtype, 'adtype_value': adtype_value,
                   'ad_formats': AD_CHOICE, 'campaign_type': CAMPAIGN_TYPE, })


@login_required
def campaign_copy(request, slug):
    campaign = Campaign.objects.get(slug=slug, user=request.user)
    new_campaign = Campaign()
    new_campaign.name = campaign.name
    new_campaign.template = campaign.template
    new_campaign.running_status = 1
    if campaign.campaign_status == 2 or campaign.campaign_status > 4:
        new_campaign.campaign_status = 5
    else:
        new_campaign.campaign_status = 1
    new_campaign.user = campaign.user
    new_campaign.active = True
    new_campaign.ad_format = campaign.ad_format
    new_campaign.campaign_type = campaign.campaign_type
    new_campaign.budget = campaign.budget
    new_campaign.cpc_cpm_bid = campaign.cpc_cpm_bid
    new_campaign.save()
    return HttpResponseRedirect("/mysite/campaign/?msg=Your Campaign has been successfully cloned.")


@login_required
def campaign_view(request, slug):
    template_name = 'myadmin/advertiser/campaign_view.html'
    campaign = None
    if slug:
        campaign = Campaign.objects.get(slug=slug, user=request.user)
        return render(request, template_name, {'campaign_obj': campaign, })
    return HttpResponseRedirect("/mysite/campaign/")


@login_required_ajax
def review_campaign(request, campaign_id):
    campaign = Campaign.objects.get(id=campaign_id, user=request.user)
    campaign.campaign_status = 3
    campaign.save()
    return HttpResponseRedirect("/mysite/campaign/?msg=Your Campaign has been send for review to our compliance team.Plesae wait for campaign Approval.")


@login_required
def campaign_paused(request,slug):
    campaign=Campaign.objects.get(slug=slug,user=request.user)
    if campaign.campaign_status == 6:
        campaign.running_status=3
        campaign.campaign_status=7
        campaign.end_date=datetime.now()
        campaign.reason_for_rejection = "This campaign was paused by account owner."
        campaign.save()
        return HttpResponseRedirect("/mysite/campaign/?msg=Your Campaign has been paused now. Please resume this campaign to send it again.")
    return HttpResponseRedirect("/mysite/campaign/?msg= Sorry we are facing some issue to paused this campaign.Please contact dailymails support team to paused this campaign ")


@login_required
def run_campaign(request,campaign_id):
    if request.user.userdetail.remaining_amount < 5:
        return HttpResponseRedirect("/mysite/campaign/?msg=Your account balance is very low.Please recharge your account to start your campaign.")
    campaign=Campaign.objects.get(id=campaign_id,user=request.user)
    campaign.running_status=2
    campaign.campaign_status=6
    campaign.start_date=datetime.now()
    campaign.save()
    return HttpResponseRedirect("/mysite/campaign/?msg= Your campaign is running now.")

@login_required
def run_campaign_remaining(request,campaign_id):
    if request.user.userdetail.remaining_amount < 5:
        return HttpResponseRedirect("/mysite/campaign/?msg=Your account balance is very low.Please recharge your account to resume your campaign.")

    campaign=Campaign.objects.get(id=campaign_id,user=request.user)
    campaign.running_status=2
    campaign.campaign_status=6
    campaign.save()
    return HttpResponseRedirect("/mysite/campaign/?msg= Your campaign has been resumed now.")

