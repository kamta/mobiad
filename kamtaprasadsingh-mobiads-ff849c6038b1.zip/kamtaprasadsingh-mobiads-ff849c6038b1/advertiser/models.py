from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.template.defaultfilters import slugify
from django.contrib.auth.models import User
from mailprocess.models import ModelBase
from mailprocess.choices import *
from template_manager.models import CampaignTemplate


class Campaign(ModelBase):
    name=models.CharField(_('Campaign Name'),max_length=100)
    template=models.ForeignKey(CampaignTemplate, on_delete=models.CASCADE, null=True,blank=True)
    ad_format = models.IntegerField(choices=AD_CHOICE,default=1)
    running_status = models.IntegerField(choices=CAMPAIGN_RUNNING_STATUS,default=1)
    campaign_status = models.IntegerField(choices=CAMPAIGN_STATUS,default=1)
    campaign_type = models.IntegerField(choices=CAMPAIGN_TYPE, default=1)
    budget = models.DecimalField(max_digits=10,decimal_places=3,default=0.000)
    cpc_cpm_bid = models.DecimalField(max_digits=10,decimal_places=3,default=0.000)
    start_date = models.DateTimeField(null=True,blank=True)
    #sent_time = models.DateTimeField(null=True,blank=True) # Not Currently in use. Will use with push ads
    end_date = models.DateTimeField(null=True,blank=True)
    #enable_scheduling=models.BooleanField(default=0) # Not Currently in use. Will use with push ads
    #timezone=models.CharField(null=True,blank=True,max_length=255) # Not Currently in use. Will use with push ads
    reason_for_rejection=models.TextField(null=True,blank=True)
    t_impression_count=models.IntegerField(default=0)
    t_click_count=models.IntegerField(default=0)
    slug=models.SlugField(max_length=255,unique=True)

    class Meta:
        pass
    def __unicode__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.id:
            super(Campaign, self).save(*args, **kwargs)
        self.slug=slugify(self.name) +"-"+ str(self.user.id)+"-"+str(self.id)
        super(Campaign, self).save(*args, **kwargs)

    def total(self):
        if self.campaign_type == 1:
            return self.cpc_cpm_bid*self.t_click_count
        else:
            return self.cpc_cpm_bid*self.t_impression_count/1000

    def ctr(self):
        return self.t_click_count*100/self.t_impression_count


class CampaignDetail(models.Model):
    """
    International Organization for Standardization (ISO) 3166-1 Country list
    """
    campaign=models.ForeignKey(Campaign, on_delete=models.CASCADE)
    report_type=models.IntegerField(choices=CAMPAIGN_TYPE, default=1)
    active=models.BooleanField(default=True)
    source_ip=models.CharField(_('IP address'), max_length=100,null=True,blank=True)
    http_referer=models.CharField(blank=True,null=True,max_length=500)
    publisher=models.ForeignKey(User, on_delete=models.CASCADE, null=True,blank=True)
    price = models.DecimalField(max_digits=10,decimal_places=3,default=0.000)
    added_date=models.DateTimeField(auto_now_add=True)
    updated_date=models.DateTimeField(auto_now=True)


