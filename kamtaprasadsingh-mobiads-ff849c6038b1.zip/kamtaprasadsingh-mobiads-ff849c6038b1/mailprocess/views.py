from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
import json
from .models import ContactUs,Country, BusinessType
from django.contrib.auth.decorators import login_required
from product.models import Product
from publisher.models import PublisherSite
from advertiser.models import Campaign, CampaignDetail
from django.db.models import Sum, Count

def aboutus(request):
    template_name ="static/aboutus.html"
    return render(request, template_name, {})
def privacy(request):
    template_name ="static/privacy.html"
    return render(request, template_name)
def terms(request):
    template_name ="static/terms.html"
    return render(request, template_name)
    
def home(request):
    template_name='index.html'
    return render(request, template_name,{'country_list':Country.objects.all(), 'business_type': BusinessType.objects.all()})

def publisher(request):
    template_name='publisher.html'
    return render(request, template_name,{'country_list':Country.objects.all(), 'business_type': BusinessType.objects.all()})

def pricing(request):
    product=Product.objects.filter(active=True)
    template_name='myadmin/pricing.html'
    return render(request, template_name,{'product':product})    
    
def htmlsitemap(request):
    brand=Brand.objects.all()
    template_name='static/sitemap.html'
    return render(request, template_name,{'brand':brand})
def contactus(request):
    if request.method == "POST":
        try:
            contact=ContactUs()
            contact.name=request.POST.get('name')
            contact.email=request.POST.get('email')
            contact.message=request.POST.get('message')
            contact.skypeid=request.POST.get('skypeid')
            contact.mobile=int(request.POST.get('whatsapp_number'))
            contact.country_id=int(request.POST.get('country'))
            contact.status=1
            contact.save()
            return HttpResponse(json.dumps(1),content_type="application/json")
        except:
            return HttpResponse(json.dumps(2),content_type="application/json")
        
@login_required(login_url='/')
def mysite(request):
    total_site = PublisherSite.objects.filter(user=request.user, active=True).count()

    campaign=Campaign.objects.filter(user=request.user,active=True)
    draft_campaign=campaign.filter(campaign_status=1).count()
    running_campaign=campaign.filter(campaign_status=6).count()
    paused_campaign=campaign.filter(campaign_status=7).count()
    in_review_campaign=campaign.filter(campaign_status=3).count()
    reviewed_campaign=campaign.filter(campaign_status=5).count()
    stopped_campaign=campaign.filter(campaign_status=8).count()
    publisher = CampaignDetail.objects.filter(publisher__username=request.user)
    impression= publisher.filter(report_type=2).count()
    clicks=publisher.filter(report_type=1).count()
    total_payouts=publisher.aggregate(total=Sum('price'))
    total_payout_value= total_payouts.get('total')
    if total_payout_value is None:
        total_payout_value = 0
    template_name="myadmin/index.html"
    return render(request, template_name, {'total_site':total_site, 'draft_campaign':draft_campaign, 'running_campaign':running_campaign,
                                           'paused_campaign':paused_campaign, 'in_review_campaign':in_review_campaign, 'reviewed_campaign':reviewed_campaign,
                                           'stopped_campaign':stopped_campaign, 'impression':impression, 'click':clicks, 'total_payouts':total_payout_value*60/100 })

