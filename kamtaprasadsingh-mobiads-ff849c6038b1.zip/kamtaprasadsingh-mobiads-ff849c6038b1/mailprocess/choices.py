AD_CHOICE = ((1, "Direct Link Ads"), (2, "Display Banner Ads"))#, (3, "Social Ads"))
CAMPAIGN_RUNNING_STATUS =((1,'Idle'), (2,'Running'), (3, "Paused"), (4,'Stopped'), (5,'Complete'))
CAMPAIGN_STATUS =((1, 'Draft'),(2, 'Scheduled On'), (3,'To Be Reviewed'), (4, 'Rejected'),(5,'Reviewed'), (6, 'Running'), (7,"Paused"), (8, 'Stopped'), (9, 'Sent'))
CAMPAIGN_TYPE = ((1, 'CPC'), (2, 'CPM'))

