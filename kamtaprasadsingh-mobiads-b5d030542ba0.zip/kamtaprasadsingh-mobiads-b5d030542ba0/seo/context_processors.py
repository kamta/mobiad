from django.conf import settings
from .models import MetaData


def globalform(request):
    metadata = MetaData.objects.filter(path=request.path)
    return {
        'metadata': metadata[0] if metadata else None
    }
