from django.core.management.base import BaseCommand
from advertiser.models import Campaign


class Command(BaseCommand):
    help = 'Update Campaign Status'

    def handle(self, *args, **options):
        campaigns=Campaign.objects.filter(campaign_status=6, active=True)
        for campaign in campaigns:
            if campaign.user.userdetail.remaining_amount < 5 and campaign.campaign_status == 6:
                campaign.running_status=3
                campaign.campaign_status=7
                campaign.save()



