from django.conf.urls import url
from django.views.generic import TemplateView
from .views import *
urlpatterns = [
    url(r'^advertiser/reports/$', advertiser_reports, name='advertiser_reports'),
    url(r'^advertiser/directlinkads/$', advertiser_directlinkads, name='advertiser_directlinkads'),
    #url(r'^advertiser/view-directlinkad/(?P<campaign_slug>.+)/$', advertiser_directlinkad_details, name='advertiser_directlinkad_details'),
    url(r'content/(?P<campaign_slug>.+)/(?P<username>.+)/$', advertiser_directlinkad_details, name='advertiser_directlinkad_details'),
    url(r'campaign/$', campaign_list, name="campaign_list"),
    url(r'campaign/add/$', campaign_change, name="campaign_change"),
    url(r'campaign/change/(?P<slug>.+)/$', campaign_change, name="campaign_change"),
    url(r'campaign/copy/(?P<slug>.+)/$', campaign_copy, name="campaign_copy"),
    url(r'campaign/view/(?P<slug>.+)/$', campaign_view, name="campaign_view"),
    url(r'campaign/review/(?P<campaign_id>\d+)/$', review_campaign, name='campaign_review'),
    url(r'campaign/paused/(?P<slug>.+)/$', campaign_paused, name="campaign_paused"),
    url(r'campaign/run/(?P<campaign_id>\d+)/$', run_campaign, name="run_campaign"),
    url(r'campaign/run/remaining/(?P<campaign_id>\d+)/$', run_campaign_remaining, name="run_campaign_remaining"),

]
