from django.contrib import admin
from models import *

class PublisherSiteAdmin(admin.ModelAdmin):
    list_display = ('site', 'ad_type', 'site_status', 'reason', 'active', 'mobile_traffic', 'desktop_traffic', 'slug',  'user', 'added_date', 'modified_date')
    list_editable = ('site_status', 'reason', 'active',  'mobile_traffic', 'desktop_traffic',)
admin.site.register(PublisherSite, PublisherSiteAdmin)

