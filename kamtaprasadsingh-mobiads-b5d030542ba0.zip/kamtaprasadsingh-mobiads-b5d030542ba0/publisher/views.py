from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render
import json
from django.contrib.auth.decorators import login_required
from mailprocess.choices import AD_CHOICE
from .models import PublisherSite
from .forms import PublisherSiteForm
from advertiser.models import CampaignDetail
from django.db.models import Sum


@login_required
def publisher_reports(request):
    template_name='myadmin/publisher/publisher_sites_reports.html'
    publishers = CampaignDetail.objects.filter(publisher__username=request.user).values('campaign__name').annotate(total=Sum('price'))
    return render(request, template_name, {'publishers':publishers,})


@login_required
def publisher_sites(request):
    template_name='myadmin/publisher/publisher_sites_list.html'
    publishers = PublisherSite.objects.filter(user=True, active = True)
    return render(request, template_name, {'publishers':publishers, })


@login_required
def change_publisher_sites(request, slug=None):
    site = None
    if slug:
        site = PublisherSite.objects.get(slug=slug)
    if request.method == "POST":
        site_instance = PublisherSite.objects.filter(site=request.POST.get('site'))
        if slug:
            site_instance = site_instance.exclude(slug=slug)
        if site_instance:
            return HttpResponseRedirect("/mysite/publisher/sites/?msg=Site %s already exist.Please try with another one." % site_instance[0].site)

        form = PublisherSiteForm(request.POST, instance=site)
        if form.is_valid():
            new_site = form.save(commit=False)
            new_site.user = request.user
            new_site.active = True
            new_site.site_status = 1
            new_site.save()
            return HttpResponseRedirect("/mysite/publisher/sites/")
        else:
            return HttpResponse(json.dumps(form.errors),content_type="application/json")
    template_name='myadmin/publisher/publisher_sites_change.html'
    return render(request, template_name, {'type_list': AD_CHOICE, 'site': site})


@login_required
def review_publisher_sites(request, site_id):
    site=PublisherSite.objects.get(id=site_id, user=request.user)
    site.site_status = 2
    site.save()
    return HttpResponseRedirect("/mysite/publisher/sites/")


@login_required
def view_publisher_sites(request,slug):
    template_name = 'myadmin/publisher/publisher_sites_view.html'
    publisher_site = PublisherSite.objects.get(slug=slug)
    return render(request, template_name,{'site': publisher_site, })


