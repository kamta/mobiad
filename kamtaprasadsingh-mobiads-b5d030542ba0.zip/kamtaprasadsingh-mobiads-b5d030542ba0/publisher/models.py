from django.db import models
from django.contrib.auth.models import User
from mailprocess.models import ModelBase, Country
from mailprocess.choices import AD_CHOICE
from django.utils.translation import ugettext_lazy as _
from django.template.defaultfilters import slugify

REVIEW_STATUS =((1, 'Draft'),(2, 'To Be Reviewed'),(3, 'Rejected'),(4, 'Reviewed'))


class PublisherSite(ModelBase):
    site = models.CharField(max_length=256, null=True, blank=True)
    ad_type = models.IntegerField(choices=AD_CHOICE, default=1)
    site_status = models.IntegerField(choices=REVIEW_STATUS, default=1)
    mobile_traffic = models.BigIntegerField(default=0)
    desktop_traffic = models.BigIntegerField(default=0)
    slug=models.SlugField(max_length=255,unique=True)
    reason = models.CharField(max_length=256, null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def save(self, *args, **kwargs):
        if not self.id:
            super(PublisherSite, self).save(*args, **kwargs)
        self.slug=slugify(self.site) +"-"+ str(self.user.id)+"-"+str(self.id)
        super(PublisherSite, self).save(*args, **kwargs)
