from django.conf.urls import url
from django.views.generic import TemplateView
from .views import *

urlpatterns = [
    url(r'^$', home, name="homepage"),
    url(r'^publisher/$', publisher, name="publisher"),
    url(r'^about-us/$',aboutus, name="aboutus"),
    url(r'^privacy/$', privacy, name="privacy"),
    url(r'^terms/$', terms, name="terms"),
    url(r'^contactus/$', contactus, name="contactus"),
    #url(r'^pricing/$', pricing, name="pricing"),
    url(r'^data-processing-agreement/$', TemplateView.as_view(template_name='static/data-processing-agreement.html'), name="gdpr"),
    url(r'^mysite/$', mysite, name='mysite'),
    url(r'^sitemap/$', htmlsitemap, name='htmlsitemap'),
    
]
