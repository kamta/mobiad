from django.contrib import admin
from models import *


class UserProfileAdmin(admin.ModelAdmin):
    list_display = (
    'user_email', 'username', 'business_type', 'country', 'mobile', 'key', 'is_api_enabled', 'total_amount',
    'remaining_amount', 'used_amount', 'skypeid', 'first_name', 'last_name', 'last_login', 'date_joined', 'address',
    'userstatus', 'login_as_user')
    list_filter = ('user__date_joined', 'user__last_login', 'userstatus')
    search_fields = ('user__email', 'user__username')

    def country(self, obj):
        if obj.country_detail:
            return obj.country_detail.name + "-idd-%s, ccd-+%s" % (obj.country_detail.idd, obj.country_detail.ccd)
        else:
            return ''

    def login_as_user(self, obj):
        return "<a href='https://mobiads.dailymails.org/accounts/signin/%s/'>login</a>" % (obj.user.username)

    login_as_user.allow_tags = True

    def first_name(self, obj):
        return obj.user.first_name

    def last_name(self, obj):
        return obj.user.last_name

    def last_login(self, obj):
        return obj.user.last_login

    def date_joined(self, obj):
        return obj.user.date_joined

    def user_email(self, obj):
        return obj.user.email

    def username(self, obj):
        return obj.user.username

    '''def get_queryset(self, request):
        qs = super(UserProfileAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(site=request.user.userdetail.site)'''


class UserUsageAdmin(admin.ModelAdmin):
    list_display = ('username', 'product', 'quantity', 'price', 'active', 'date')
    list_filter = ('product__name', 'userusage__user',)

    def username(self, obj):
        return obj.userusage.user.username


admin.site.register(UserUsage, UserUsageAdmin)
admin.site.register(UserProfile, UserProfileAdmin)
