from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.models import User
from django.template.defaultfilters import slugify
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.template import RequestContext, loader
import json
import random
import string
from django.db.models import Q,Sum
import requests
from decimal import Decimal
import datetime
from mailprocess.decorators import login_required_ajax
from payment.models import PaymentPlan,PaymentTrack


@login_required(login_url='/')
def payment_history(request):
    payment_history=PaymentTrack.objects.filter(user=request.user,status='2').order_by("-payment_date_time")
    total=payment_history.aggregate(Sum('amount'))
    template_name='myadmin/payment/payment_history.html'
    return render(request, template_name,{'payment_history':payment_history,'total':total.get("amount__sum")})


@login_required(login_url='/')
def purchase_credit(request):
    if request.method == "POST":
        paymentplan=request.POST.get('paymentplan')
        total_price=PaymentPlan.objects.get(id=paymentplan).price
        try:          
            #res=requests.get("https://www.google.co.in/search?q=usd+to+rs+converter")
            #rate=Decimal(res.text.split("1 USD, ")[1].split(" INR. 5 USD,")[0].strip())
            res=requests.get("https://api.ratesapi.io/api/latest?base=USD")
            rate=Decimal(res.json().get('rates').get('INR'))
        except:
            rate=Decimal(73.00)
        paymenttrack=PaymentTrack(status='1',source="1",user=request.user,amount=total_price,plan_id=paymentplan,rate=rate)
        paymenttrack.save()
        request.session["order_id"]=paymenttrack.id
        template_name='myadmin/payment.html'
        return render(request, template_name,{'paymenttotal':Decimal(total_price)*rate,'total_price':total_price})
    payment_plan=PaymentPlan.objects.filter(active=True)
    template_name='myadmin/payment/purchase_credit.html'
    return render(request, template_name,{'payment_plan':payment_plan})

def payment(request):
    payment_id = request.GET.get("payment_id")
    status = request.GET.get("status")
    order_id=request.session.get('order_id',False)
    paypal=request.GET.get("paypal")
    if status == 'success' and payment_id and order_id:
        if paypal:
            amount = 0
        else:
            headers = {'X-Api-Key': '042d039b340b833c986a402810732d9d',
                   'X-Auth-Token': 'fe47501667baf724c292e4f84c877759'}

            res = requests.get('https://www.instamojo.com/api/1.1/payments/%s/' %(payment_id), headers=headers)
            value=json.loads(res.text)        
            amount = 0#int(float(value.get('payment').get('amount')))

        paymenttrack=PaymentTrack.objects.get(id=order_id)
        paymenttrack.status="2"
        paymenttrack.payment_id=payment_id
        paymenttrack.payment_date_time=datetime.datetime.now()
        if amount == 0:
            paymenttrack.amount_received=paymenttrack.amount            
        else:            
            paymenttrack.amount_received=amount
        paymenttrack.save()
        profile=request.user.userdetail
        profile.total_amount+=paymenttrack.amount
        profile.remaining_amount+=paymenttrack.amount
        profile.save()
        

        try:
            del request.session['order_id']
        except:
            pass
        return HttpResponseRedirect("https://emailvalidators.com/mysite/")
    return HttpResponseRedirect("https://emailvalidators.com/")
