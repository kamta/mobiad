from django.db import models
from django.contrib.auth.models import User
from mailprocess.models import Country
from django.utils.translation import ugettext_lazy as _

PAYMENT_CHOICE=(('1',"Pending Payment"),('2',"Verified"))
SOURCE_CHOICE=(('1','Prepaid'),('2',"POST PAID"))

class PaymentPlan(models.Model):
    name=models.CharField(max_length=500,null=True,blank=True)
    price=models.PositiveIntegerField(default=10)
    active=models.BooleanField(default=True)
    def __unicode__(self):
        return str(self.name)
class PaymentTrack(models.Model):
    payment_id=models.CharField(max_length=500,null=True,blank=True)
    status=models.CharField(max_length=1,choices=PAYMENT_CHOICE,default='1')
    source=models.CharField(max_length=1,choices=SOURCE_CHOICE,default='1')
    amount=models.DecimalField(max_digits=10,decimal_places=2,default=0.00)
    amount_received=models.DecimalField(max_digits=10,decimal_places=2,default=0.00)
    rate=models.DecimalField(max_digits=5,decimal_places=2,default=0.00)    
    user=models.ForeignKey(User,related_name="payment_user")
    plan=models.ForeignKey(PaymentPlan)
    added_date_time=models.DateTimeField(auto_now_add=True)
    payment_date_time=models.DateTimeField(null=True,blank=True)
    


    def __unicode__(self):
        return str(self.id)
