from django.db import models
from django.utils.translation import ugettext_lazy as _
from mailprocess.models import ModelBase
from django.template.defaultfilters import slugify
from django.db.models.signals import post_save
from django.dispatch import receiver
from mailprocess.choices import AD_CHOICE

class TemplateCategory(ModelBase):
    name = models.CharField(_('Template Category Name'), max_length=100)
    slug = models.SlugField(unique=True)

    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = _('Template Category')
        verbose_name_plural = _('Template Categories')

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super(TemplateCategory, self).save(*args, **kwargs)


class CampaignTemplate(ModelBase):
    template_name = models.CharField(max_length=100)
    template_type=models.IntegerField(choices=AD_CHOICE, default=1)
    headline1 = models.CharField(max_length= 30)
    headline2 = models.CharField(max_length= 25, null=True, blank=True)
    description1 = models.CharField(max_length= 60)
    description2 = models.CharField(max_length= 60, null=True, blank=True)
    adimage = models.ImageField(upload_to='uploads/adimage/', null=True, blank=True)
    icon = models.ImageField(upload_to='uploads/pushicon/', null=True, blank=True)
    final_url = models.URLField()
    display_url = models.URLField()
    templatecategory = models.ForeignKey(TemplateCategory)
    is_public = models.BooleanField(default=False)
    slug = models.SlugField(unique=True)

    class Meta:
        verbose_name = _('CampaignTemplate')
        verbose_name_plural = _('CampaignTemplates')

    def __unicode__(self):
        return str(self.pk)

    def save(self, *args, **kwargs):
        self.slug = slugify(self.template_name) + str(self.pk) + "-" + str(self.user.id)
        super(CampaignTemplate, self).save(*args, **kwargs)

        

@receiver(post_save, sender=CampaignTemplate)
def update_campaign(sender, instance, created, **kwargs):
    if not created:        
        from advertiser.models import Campaign
        Campaign.objects.filter(template=instance,campaign_status__in=[2,4,5]).update(campaign_status=1)






