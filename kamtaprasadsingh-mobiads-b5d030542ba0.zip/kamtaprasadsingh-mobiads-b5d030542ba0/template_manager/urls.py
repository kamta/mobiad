from django.conf.urls import url
from views import templates_list, templates_change, templates_preview, templates_delete

urlpatterns = [
    url(r'templates/$', templates_list, name="templates_list"),
    url(r'templates/add/$', templates_change, name="templates_change"),
    url(r'templates/change/(?P<slug>.+)/$', templates_change, name="templates_change"),
    url(r'templates/preview/(?P<slug>.+)/$', templates_preview, name="templates_preview"),
    url(r'templates/delete/(?P<slug>.+)/$', templates_delete, name="templates_delete"),

]
