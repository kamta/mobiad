from __future__ import absolute_import

from django import forms
from .models import CampaignTemplate


class EmailTemplateForm(forms.ModelForm):
    class Meta:
        model = CampaignTemplate
        exclude = ('user','slug')



