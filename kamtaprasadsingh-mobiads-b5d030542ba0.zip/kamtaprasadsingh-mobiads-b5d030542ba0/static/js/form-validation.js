jQuery.validator.addMethod("alphanumericonly", function(value, element) {
	return this.optional(element) || /^[a-z0-9]*$/i.test(value);
}, "Small Letters and numbers only please");

$("#userregistrationbutton").click(function(){

                $('#site-user-registration-form').validate({ // initialize the plugin
                    rules: {
                        email: {
                            required: true,
                            email: true
                        },
                        username: {
                            required: true,
                            alphanumericonly: true
                        },
                        mobile: {
                            required: true,
                            digits: true,
                            minlength : 4,
                            maxlength : 14
                        },
                        password: {
                            required: true,
                            minlength : 5
                        }
                    },
                    submitHandler: function (form) {

                    $('#userregistrationbutton').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/register/user/",
                           data: $("#site-user-registration-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {
                               if (data == 1)
                               {
                                   $('.alert-success').removeClass('hidden');
                                   $('.alert-info').addClass('hidden');                                   
                                   $('.form-control').val("");
				   setTimeout(function(){
			              document.location="/mysite/";
					}, 5000);
                               }
                               if (data == 2)
                               {
                                   $('.alert-info').removeClass('hidden');
                                   $('.alert-success').addClass('hidden');

                               }
                               $('#userregistrationbutton').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });
 $("#btn_contact_submit").click(function(){

                $('#contact-form').validate({ // initialize the plugin
                    rules: {
                        email: {
                            required: true,
                            email: true
                        },
                        name: {
                            required: true
                        },
			//skypeid: {
		        //    required: true
			//    },
			whatsapp_number: {
			    required: true,
                            digits: true,
                            minlength : 4,
                            maxlength : 14
		    },
                        message: {
                            required: true,
                            minlength : 50
                        }
                    },
                    submitHandler: function (form) {

                    $('#btn_contact_submit').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/contactus/",
                           data: $("#contact-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {


                               if (data == 1)
                               {
                                  $('.alert-info').show();
                                   $('.alert-warning').hide();
                                   $('.form-control').val("");

                               }
                               //if (data == 2)
                               else
                               {
                                   $('.alert-warning').show();
                                   $('.alert-info').hide();

                               }
                               $('#btn_contact_submit').removeAttr('disabled').html('Send Message');

                           }
                         });
                    }
                });



            });

 $("#userprofiles_button").click(function(){

                $('#userprofile-form').validate({ // initialize the plugin
                    rules: {

                        first_name: {
                            required: true
                        },

                        mobile: {
                            required: true,
                            digits: true,
                            minlength : 4,
                            maxlength : 14
                        }
                    },
                    submitHandler: function (form) {

                    $('#userprofiles_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/",
                           data: $("#userprofile-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/accounts";

                               }
                               else if (data == 5){
                                document.location="/";
                                
                               }
                               else
                               {
                                   $('#userprofile-form .alert-warning').removeClass('hidden');


                               }
                               $('#userprofiles_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });

 $("#companydetails_button").click(function(){

                $('#companydetails-form').validate({ // initialize the plugin
                    rules: {

                        company: {
                            required: true,
                            minlength:6
                        },

                        website: {
                            required: true,
                            minlength : 5
                        },
                        address: {
                            required: true,
                            minlength : 5
                        }
                    },
                    submitHandler: function (form) {

                    $('#companydetails_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/companydetails/",
                           data: $("#companydetails-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/accounts/";

                               }
                               else if (data == 3){
                                   document.location="/";
                               }
                               else
                               {
                                   $('#companydetails-form .alert-warning').removeClass('hidden');


                               }
                               $('#companydetails_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });

 $("#changepassword_button").click(function(){

                $('#changepassword-form').validate({ // initialize the plugin
                    rules: {

                        new_password: {
                            required: true
                        },

                        confirm_password: {
                            equalTo: "#new_password"
                        }
                    },
                    submitHandler: function (form) {

                    $('#changepassword_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/change/password/",
                           data: $("#changepassword-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/";

                               }
                               else if (data == 3){
                                   document.location="/";
                               }
                               else
                               {
                                   $('.alert-warning').removeClass('hidden');


                               }
                               $('#changepassword_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });

 $("#template_button").click(function(){
                $('#template_form').validate({ // initialize the plugin
                    rules: {
                        adimage:{
                            required:true,
                            extension: "jpg|jpeg|png|gif"
                        },
                        template_name: {
                            required: true,
                            maxlength:50
                        },
                        headline1: {
                            required: true,
                            maxlength:30
                        },
                        description1: {
                            required: true,
                            maxlength:59
                        },
                        display_url: {
                            required: true,
                            url: true

                        },
                        final_url: {
                            required: true,
                            url: true

                        }
                    },
                    submitHandler: function (form) {
                    var formData = new FormData(form);
                    $('#template_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: $(form).action,
                           data: formData, // serializes the form's elements.
                           mimeType: "multipart/form-data",
                           contentType: false,
                           cache: false,
                           processData: false,
                           dataType : 'json',
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/mysite/templates/";

                               }
                               else if (data == 5){
                                document.location="/";

                               }
                               else
                               {
                                   $('.error-message').show();
                                   errorval=""
                                   for (var key in data) {
                                       errorval += key +" :  "+ data[key] + "<br>"
                                    }
                                   $('.error-message').html(errorval);

                               }
                               $('#template_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



 });

$("#campaign_button").click(function(){
                $('#campaignform').validate({ // initialize the plugin
                    rules: {

                        name: "required",
                        cpc_cpm_bid: {
                            required: true,
                            min: 0.01
                        },
                        budget: {
                            required: true,
                            min: 1
                        },
                    },
                    submitHandler: function (form) {
                    $('#campaign_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: $(form).action,
                           data: $("#campaignform").serialize(), // serializes the form's elements.
                           dataType : 'json',
                           success: function(data)
                           {
                               if (data == 1)
                               {
                                 document.location="/mysite/campaign/";
                               }
                               else
                               {
                                  $('.error-message').show();
                                   errorval=""
                                   for (var key in data) {
                                       errorval += key +" :  "+ data[key] + "<br>"
                                    }
                                   $('.error-message').html(errorval);
                               }
                               $('#campaign_button').removeAttr('disabled').html('Submit');
                           }
                         });
                    }
                });
 });

 
 $("#datefilter").click(function(){
 if( !$('#fromdatepicker').val())
 {
 alert("Please choose From Date ");
 return;
 }
 else if ( !$('#todatepicker').val())
 {
 alert("Please choose To Date ");
 return;
 }
else{
 document.location="?fromdate="+$('#fromdatepicker').val()+"&todate="+$('#todatepicker').val();
}
});

  
